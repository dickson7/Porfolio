//pestañas de pago

tabControl();


var resizeTimer;
$(window).on('resize', function(e) {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function() {
    tabControl();
  }, 250);
});

function tabControl() {
  var tabs = $('.tabbed-content').find('.tabs');
  if(tabs.is(':visible')) {
    tabs.find('a').on('click', function(event) {
      event.preventDefault();
      var target = $(this).attr('href'),
          tabs = $(this).parents('.tabs'),
          buttons = tabs.find('a'),
          item = tabs.parents('.tabbed-content').find('.item');
      buttons.removeClass('active');
      item.removeClass('active');
      $(this).addClass('active');
      $(target).addClass('active');
    });
  } else {
    $('.item').on('click', function() {
      var container = $(this).parents('.tabbed-content'),
          currId = $(this).attr('id'),
          items = container.find('.item');
      container.find('.tabs a').removeClass('active');
      items.removeClass('active');
      $(this).addClass('active');
      container.find('.tabs a[href$="#'+ currId +'"]').addClass('active');
    });
  } 
}

//boton continuar
// const $button = document.getElementById('continuar');
//const $activ_envio = document.getElementById('pills-profile-tab');

//$button.addEventListener('click', () =>{
//  $activ_envio.classList.add('active');
//   $activ_envio.classList.add('show-select');
//})

$( "#continuar" ).click(function(e) {
    e.preventDefault();
  $('#pills-profile-tab').tab('show');
  $('#check').addClass('icon-check');
})
